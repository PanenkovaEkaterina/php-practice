<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 1 - Форма регистрации</title>
    <style> body { font-family: Arial, sans-serif; margin: 40px; } </style>
</head>
<body>
    <h1>Регистрация на курсы заочной школы программирования</h1>
    
    <form action="task1_handler.php" method="POST">
        <p>Имя: <input type="text" name="first_name" required></p>
        <p>Фамилия: <input type="text" name="last_name" required></p>
        <p>Возраст: <input type="number" name="age" min="10" max="100"></p>
        
        <p>Выберите курсы:</p>
        <input type="checkbox" name="kurs[]" value="PHP"> PHP<br>
        <input type="checkbox" name="kurs[]" value="JavaScript"> JavaScript<br>
        <input type="checkbox" name="kurs[]" value="Python"> Python<br>
        <input type="checkbox" name="kurs[]" value="C++"> C++<br>
        <input type="checkbox" name="kurs[]" value="Web-дизайн"> Web-дизайн<br>
        
        <br>
        <input type="submit" value="Зарегистрироваться">
    </form>
</body>
</html>