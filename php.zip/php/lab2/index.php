<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Лабораторная работа №2 - Обработка форм</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h1 { color: #333; }
        ul { font-size: 18px; line-height: 2.2; }
    </style>
</head>
<body>
    <h1>Лабораторная работа №2</h1>
    <h2>Обработка форм в PHP</h2>
    
    <ul>
        <li><a href="task1_form.php">1. Пример формы регистрации (из лабораторной)</a></li>
        <li><a href="task1_handler.php">1. Обработчик формы</a></li>
        <li><a href="task2.php">2. Форма с валидацией (ФИО, email, телефон)</a></li>
        <li><a href="task3.php">3. Генерация таблицы по размерам</a></li>
    </ul>
</body>
</html>