<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 2 - Форма с валидацией</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .error { color: red; }
        .success { color: green; }
        input { margin: 5px 0; padding: 8px; width: 300px; }
    </style>
</head>
<body>
    <h1>Задание 2 — Ввод и проверка данных пользователя</h1>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $fio    = trim($_POST['fio'] ?? '');
        $email  = trim($_POST['email'] ?? '');
        $phone  = trim($_POST['phone'] ?? '');

        $errors = [];

        // Проверка ФИО
        if (empty($fio)) {
            $errors[] = "ФИО обязательно для заполнения";
        } elseif (!preg_match('/^[А-ЯЁ][а-яё]+(?:\s[А-ЯЁ][а-яё]+){1,2}$/u', $fio)) {
            $errors[] = "ФИО должно содержать только русские буквы. Каждое слово должно начинаться с заглавной буквы.";
        }

        // Проверка Email
        if (empty($email)) {
            $errors[] = "Email обязателен";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Неверный формат email";
        }

        // Проверка телефона
        if (empty($phone)) {
            $errors[] = "Телефон обязателен";
        } elseif (!preg_match('/^(\+7|8)?[\s-]?\(?(\d{3})\)?[\s-]?(\d{3})[\s-]?(\d{2})[\s-]?(\d{2})$/', $phone)) {
            $errors[] = "Телефон должен быть в формате +7XXXXXXXXXX или 8XXXXXXXXXX";
        }

        if (empty($errors)) {
            echo "<h2 class='success'>✅ Данные успешно прошли проверку!</h2>";
            echo "<div class='success'>";
            echo "<p><strong>ФИО:</strong> " . htmlspecialchars($fio) . "</p>";
            echo "<p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>";
            echo "<p><strong>Телефон:</strong> " . htmlspecialchars($phone) . "</p>";
            echo "</div>";
        } else {
            echo "<h2 class='error'>❌ Обнаружены ошибки:</h2>";
            echo "<ul class='error'>";
            foreach ($errors as $error) {
                echo "<li>$error</li>";
            }
            echo "</ul>";
        }
    }
    ?>

    <form method="POST">
        <p>ФИО:<br>
            <input type="text" name="fio" placeholder="Иванов Иван Иванович" required>
        </p>
        <p>E-mail:<br>
            <input type="email" name="email" placeholder="example@mail.ru" required>
        </p>
        <p>Телефон:<br>
            <input type="tel" name="phone" placeholder="+71234567890 или 81234567890" required>
        </p>
        <input type="submit" value="Отправить данные">
    </form>

    <br>
    <a href="index.php">← На главную</a>
</body>
</html>