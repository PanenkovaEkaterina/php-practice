<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = htmlspecialchars($_POST['first_name'] ?? '');
    $last_name  = htmlspecialchars($_POST['last_name'] ?? '');
    $age        = htmlspecialchars($_POST['age'] ?? '');
    $kurs       = $_POST['kurs'] ?? [];

    echo "<h1>Регистрация прошла успешно!</h1>";
    echo "<p>Здравствуйте, <b>$first_name $last_name</b>!</p>";
    
    if (!empty($kurs)) {
        echo "<p>Вы записаны на следующие курсы:</p><ul>";
        foreach ($kurs as $k) {
            echo "<li><b>$k</b></li>";
        }
        echo "</ul>";
    } else {
        echo "<p>Вы пока не выбрали ни одного курса.</p>";
    }
    
    if ($age) echo "<p>Ваш возраст: $age лет</p>";
}
?>

<p><a href="task1_form.php">← Заполнить форму заново</a></p>
<p><a href="index.php">← На главную</a></p>