<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 3 - Генерация таблицы</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        table { border-collapse: collapse; margin: 20px 0; }
        td, th { border: 1px solid #333; padding: 10px; text-align: center; min-width: 40px; }
        th { background-color: #f0f0f0; }
        input, button { padding: 8px; margin: 5px; }
    </style>
</head>
<body>
    <h1>Задание 3 — Генерация таблицы по размерам</h1>

    <form method="POST">
        <p>Количество строк: 
            <input type="number" name="rows" min="1" max="50" value="5" required>
        </p>
        <p>Количество столбцов: 
            <input type="number" name="cols" min="1" max="20" value="5" required>
        </p>
        <button type="submit">Создать таблицу</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $rows = (int)$_POST['rows'];
        $cols = (int)$_POST['cols'];

        if ($rows > 0 && $cols > 0) {
            echo "<h2>Таблица {$rows} × {$cols}</h2>";
            echo "<table>";

            for ($i = 1; $i <= $rows; $i++) {
                echo "<tr>";
                for ($j = 1; $j <= $cols; $j++) {
                    $value = $i * $j; // можно оставить просто $i . "," . $j
                    echo "<td>" . $value . "</td>";
                }
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "<p style='color:red'>Ошибка: количество строк и столбцов должно быть больше 0.</p>";
        }
    }
    ?>

    <br>
    <a href="index.php">← На главную</a>
</body>
</html>