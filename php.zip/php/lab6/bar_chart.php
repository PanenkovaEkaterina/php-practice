<?php
$width = 850;
$height = 620;
$image = imagecreatetruecolor($width, $height);

$white = imagecolorallocate($image, 255, 255, 255);
$black = imagecolorallocate($image, 0, 0, 0);
$gray  = imagecolorallocate($image, 220, 220, 220);

imagefill($image, 0, 0, $white);

// Параметры диаграммы
$padding_left = 80;
$padding_bottom = 90;
$chart_width = $width - $padding_left - 60;
$chart_height = $height - $padding_bottom - 50;

$num_bars = rand(5, 12);
$values = [];
for ($i = 0; $i < $num_bars; $i++) {
    $values[] = rand(-50, 180);
}

$max_value = max(array_map('abs', $values)) ?: 100;

// Оси
imageline($image, $padding_left, $height - $padding_bottom, $width - 40, $height - $padding_bottom, $black); // X
imageline($image, $padding_left, $height - $padding_bottom, $padding_left, 40, $black); // Y

// Сетка
for ($i = 1; $i <= 5; $i++) {
    $y = $height - $padding_bottom - ($chart_height / 5 * $i);
    imageline($image, $padding_left - 5, $y, $width - 40, $y, $gray);
}

// Столбцы
$bar_width = $chart_width / ($num_bars * 2);
$spacing = $bar_width;

for ($i = 0; $i < $num_bars; $i++) {
    $bar_height = ($values[$i] / $max_value) * $chart_height;
    $x1 = $padding_left + $i * ($bar_width + $spacing) + $spacing;
    $x2 = $x1 + $bar_width;
    $y1 = $height - $padding_bottom;
    $y2 = $y1 - $bar_height;

    $color = imagecolorallocate($image, rand(50, 230), rand(50, 230), rand(80, 255));
    imagefilledrectangle($image, $x1, $y2, $x2, $y1, $color);

    // Значение над столбцом (нормальным шрифтом)
    $text = (string)$values[$i];
    $font = 'C:\Windows\Fonts\arial.ttf';   // стандартный шрифт Windows
    imagettftext($image, 11, 0, $x1 + ($bar_width - 15)/2, $y2 - 15, $black, $font, $text);
}

// Подписи осей нормальным шрифтом
$font = 'C:\Windows\Fonts\arial.ttf';

imagettftext($image, 12, 0, $width/2 - 50, $height - 25, $black, $font, 'X — Столбцы');
imagettftext($image, 12, 90, 35, $height/2 + 60, $black, $font, 'Y — Значение');

header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
?>