<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Лабораторная работа №6</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; text-align: center; background: #f9f9f9; }
        h1, h2 { color: #333; }
        img { 
            border: 3px solid #333; 
            margin: 20px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            max-width: 850px;
        }
        .buttons a {
            display: inline-block;
            margin: 10px 8px;
            padding: 12px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
        .buttons a:hover { background: #0056b3; }
    </style>
</head>
<body>
    <h1>Лабораторная работа №6</h1>
    <h2>Работа с графикой в PHP</h2>

    <!-- Столбчатая диаграмма -->
    <h3>1. Столбчатая диаграмма (обязательное)</h3>
    <img id="barImg" src="bar_chart.php" alt="Столбчатая диаграмма">
    <br>
    <div class="buttons">
        <a href="bar_chart.php" target="_blank">Открыть в новом окне</a>
        <a href="#" onclick="document.getElementById('barImg').src = 'bar_chart.php?' + Date.now(); return false;">Обновить</a>
    </div>

    <hr>

    <!-- Круговая диаграмма -->
    <h3>2. Круговая диаграмма (дополнительное)</h3>
    <img id="pieImg" src="pie_chart.php" alt="Круговая диаграмма">
    <br><br>
    <div class="buttons">
        <a href="#" onclick="document.getElementById('pieImg').src = 'pie_chart.php?' + Date.now(); return false;">Построить новую</a>
        <a href="#" onclick="document.getElementById('pieImg').src = 'pie_chart.php?action=load&' + Date.now(); return false;">Считать из файла</a>
        <a href="#" onclick="document.getElementById('pieImg').src = 'pie_chart.php?' + Date.now(); return false;">Обновить</a>
    </div>

    <br><br>
    <a href="index.php">Обновить всю страницу</a>

</body>
</html>