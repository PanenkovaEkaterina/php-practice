<?php
// Обработка действий
$action = $_GET['action'] ?? 'random';

if ($action === 'load' && file_exists('pie_data.txt')) {
    $data = [];
    $lines = file('pie_data.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $parts = array_map('trim', explode(':', $line));
        if (count($parts) >= 4) {
            $data[] = [
                'value' => (int)$parts[0],
                'r' => (int)$parts[1],
                'g' => (int)$parts[2],
                'b' => (int)$parts[3]
            ];
        }
    }
} else {
    // Случайные данные
    $num = rand(4, 8);
    $data = [];
    for ($i = 0; $i < $num; $i++) {
        $data[] = [
            'value' => rand(10, 120),
            'r' => rand(40, 255),
            'g' => rand(40, 255),
            'b' => rand(40, 255)
        ];
    }
}

// --- Генерация изображения ---
$total = array_sum(array_column($data, 'value')) ?: 1;

$width = 700;
$height = 750;
$image = imagecreatetruecolor($width, $height);
$white = imagecolorallocate($image, 255, 255, 255);
$black = imagecolorallocate($image, 0, 0, 0);

imagefill($image, 0, 0, $white);

$center_x = $width / 2;
$center_y = $height / 2 - 30;
$radius = 240;

$start = 0;
foreach ($data as $sector) {
    $angle = ($sector['value'] / $total) * 360;
    $color = imagecolorallocate($image, $sector['r'], $sector['g'], $sector['b']);
    
    imagefilledarc($image, $center_x, $center_y, $radius*2, $radius*2, $start, $start + $angle, $color, IMG_ARC_PIE);
    
    // Текст в секторе
    $mid = $start + $angle/2;
    $tx = $center_x + ($radius * 0.65) * cos(deg2rad($mid));
    $ty = $center_y + ($radius * 0.65) * sin(deg2rad($mid));
    
    imagettftext($image, 13, 0, $tx-12, $ty+6, $black, 'C:\Windows\Fonts\arial.ttf', $sector['value']);
    
    $start += $angle;
}

imagearc($image, $center_x, $center_y, $radius*2, $radius*2, 0, 360, $black);

// Выводим изображение
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
exit();
?>