<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 7 - Таблица умножения</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        h1 { text-align: center; }
        table { border-collapse: collapse; margin: 20px auto; }
        td, th { border: 1px solid #333; padding: 8px 12px; text-align: center; }
        th { background-color: #e0e0e0; }
        tr:nth-child(even) { background-color: #f9f9f9; }
    </style>
</head>
<body>
    <h1>Задание 7 — Таблица умножения</h1>
    
    <table>
        <?php
        // Заголовок
        echo "<tr><th>×</th>";
        for ($i = 1; $i <= 10; $i++) {
            echo "<th>$i</th>";
        }
        echo "</tr>";

        // Сама таблица
        for ($i = 1; $i <= 10; $i++) {
            echo "<tr><th>$i</th>";
            for ($j = 1; $j <= 10; $j++) {
                echo "<td>" . ($i * $j) . "</td>";
            }
            echo "</tr>";
        }
        ?>
    </table>

    <p><a href="test.php">← Вернуться на главную</a></p>
</body>
</html>