<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Лабораторная работа №1 - Основы PHP</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h1 { color: #333; }
        ul { font-size: 18px; line-height: 2; }
    </style>
</head>
<body>
    <h1>Лабораторная работа №1</h1>
    <h2>Основы языка PHP</h2>
    
    <ul>
        <li><a href="task2.php">2. Пример из лабораторной</a></li>
        <li><a href="task3.php">3. phpinfo()</a></li>
        <li><a href="task4.php">4. Hello World!!!</a></li>
        <li><a href="task5.php">5. Информация о разработчике</a></li>
        <li><a href="task6.php">6. Таблица цветов HTML</a></li>
        <li><a href="task7.php">7. Таблица умножения</a></li>
        <li><a href="task8.php">8. Специальный вывод чисел (100 строк)</a></li>
    </ul>
</body>
</html>