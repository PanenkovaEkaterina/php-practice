<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 5 - Информация о разработчике</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
    </style>
</head>
<body>
    <h1>Задание 5 — Информация о разработчике</h1>
    
    <?php
        include "developer.txt";
    ?>
    
    <br>
    <a href="test.php">← Вернуться на главную</a>
</body>
</html>