<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 6 - Таблица цветов</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        table { border-collapse: collapse; width: 100%; margin: 20px auto; }
        td, th { border: 1px solid #333; padding: 10px; text-align: center; font-family: monospace; }
        th { background-color: #f0f0f0; }
    </style>
</head>
<body>
    <h1>Задание 6 — Таблица возможных цветов HTML (RGB)</h1>
    
    <table>
        <tr>
            <th>Красный</th>
            <th>Зелёный</th>
            <th>Синий</th>
            <th>Цвет</th>
            <th>HEX-код</th>
        </tr>
        <?php
        for ($r = 0; $r <= 255; $r += 51) {
            for ($g = 0; $g <= 255; $g += 51) {
                for ($b = 0; $b <= 255; $b += 51) {
                    $color = sprintf("#%02x%02x%02x", $r, $g, $b);
                    $brightness = $r + $g + $b;
                    $text_color = ($brightness > 500) ? 'black' : 'white';
                    
                    echo "<tr>";
                    echo "<td>$r</td>";
                    echo "<td>$g</td>";
                    echo "<td>$b</td>";
                    echo "<td style='background-color: $color; color: $text_color;'>Цвет</td>";
                    echo "<td>$color</td>";
                    echo "</tr>";
                }
            }
        }
        ?>
    </table>

    <p><a href="test.php">← Вернуться на главную</a></p>
</body>
</html>