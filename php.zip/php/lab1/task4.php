<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 4 - Hello World</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; text-align: center; }
        h1 { color: #0066cc; font-size: 3em; }
    </style>
</head>
<body>
    <h1><?php echo "Hello World!!!"; ?></h1>
    <p>Это моя первая PHP-страница.</p>
    <p>Сегодня: <?php echo date("d.m.Y H:i"); ?></p>
    <br>
    <a href="test.php">← Вернуться на главную</a>
</body>
</html>