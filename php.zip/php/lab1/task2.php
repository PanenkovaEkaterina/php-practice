<?php
    $rows = 5;
    $columns = 3;
    
    echo '<!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>Задание 2 — Пример из лабораторной</title>
        <style>
            table { border-collapse: collapse; margin: 20px auto; }
            td { 
                width: 100px; 
                height: 50px; 
                text-align: center; 
                font-weight: bold;
                border: 2px solid #333;
            }
        </style>
    </head>
    <body>';
    
    echo '<h1>Задание 2 — Реализация примера из лабораторной</h1>';
    echo '<p>Таблица ' . $rows . ' строк на ' . $columns . ' столбца</p>';
    
    echo '<table>';
    
    for ($i = 1; $i <= $rows; $i++) {
        echo '<tr>';
        
        for ($j = 1; $j <= $columns; $j++) {
            if ((($i + $j) % 2) == 0) {
                $color = "#000000";   // чёрный
                $text_color = "#ffffff";
            } else {
                $color = "#ffffff";   // белый
                $text_color = "#000000";
            }
            
            echo "<td style='background-color: $color; color: $text_color;'>$i,$j</td>";
        }
        
        echo '</tr>';
    }
    
    echo '</table>';
    echo '<p><a href="test.php">← Вернуться на главную</a></p>';
    echo '</body></html>';
?>