<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 8 - Специальный вывод</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        h1 { text-align: center; }
        .line { margin: 2px 0; font-family: monospace; }
    </style>
</head>
<body>
    <h1>Задание 8 — Вывод 100 строк</h1>
    <p>Числа от 10 до 23. Числа 12–15 выводятся по два раза, 16 — пропускается.</p>
    
    <?php
    for ($row = 1; $row <= 100; $row++) {
        echo "<div class='line'>";
        
        for ($n = 10; $n <= 23; $n++) {
            if ($n == 16) continue;  // пропускаем 16
            
            if ($n >= 12 && $n <= 15) {
                echo $n . " " . $n . " ";
            } else {
                echo $n . " ";
            }
        }
        echo "</div>";
    }
    ?>
    
    <br>
    <a href="test.php">← Вернуться на главную</a>
</body>
</html>