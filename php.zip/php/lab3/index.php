<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Лабораторная работа №3 - Работа с файлами</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h1 { color: #333; }
        ul { font-size: 18px; line-height: 2.2; }
    </style>
</head>
<body>
    <h1>Лабораторная работа №3</h1>
    <h2>Работа с файлами в PHP</h2>
    
    <ul>
        <li><a href="task1.php">1. Создание директории</a></li>
        <li><a href="task2.php">2. Объединение трёх файлов</a></li>
        <li><a href="task3.php">3. Частотный анализ строк в файле</a></li>
        <li><a href="guestbook.php">4. Гостевая книга</a></li>
    </ul>
</body>
</html>