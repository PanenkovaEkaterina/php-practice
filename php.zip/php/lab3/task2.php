<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 2 - Объединение трёх файлов</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        table { border-collapse: collapse; margin: 20px 0; }
        td, th { border: 1px solid #333; padding: 8px 12px; text-align: left; }
        th { background-color: #f0f0f0; }
        .success { color: green; }
    </style>
</head>
<body>
    <h1>Задание 2 — Объединение содержимого трёх файлов</h1>

    <?php
    $files = ['file1.txt', 'file2.txt', 'file3.txt'];
    $all_lines = [];
    $max_lines = 0;

    // Читаем все файлы
    foreach ($files as $index => $filename) {
        if (file_exists($filename)) {
            $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $all_lines[$index] = $lines;
            $max_lines = max($max_lines, count($lines));
        } else {
            $all_lines[$index] = [];
            echo "<p style='color:red'>Файл <b>$filename</b> не найден!</p>";
        }
    }

    if ($max_lines > 0) {
        echo "<p class='success'>✅ Файлы успешно прочитаны. Максимальное количество строк: $max_lines</p>";
        
        echo "<table>";
        echo "<tr><th>№</th><th>Файл 1</th><th>Файл 2</th><th>Файл 3</th></tr>";

        for ($i = 0; $i < $max_lines; $i++) {
            echo "<tr>";
            echo "<td>" . ($i + 1) . "</td>";
            
            for ($j = 0; $j < 3; $j++) {
                $text = isset($all_lines[$j][$i]) ? htmlspecialchars($all_lines[$j][$i]) : "<i>—</i>";
                echo "<td>$text</td>";
            }
            
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color:red'>Нет данных для отображения. Проверьте наличие файлов.</p>";
    }
    ?>

    <br>
    <a href="index.php">← На главную</a>
</body>
</html>