<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 1 - Создание директории</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        input { padding: 8px; width: 300px; }
    </style>
</head>
<body>
    <h1>Задание 1 — Создание директории</h1>

    <form method="POST">
        <p>Имя директории:<br>
            <input type="text" name="dirname" placeholder="my_folder" required>
        </p>
        <button type="submit">Создать папку</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $dirname = trim($_POST['dirname']);
        
        // Защита от опасных символов
        $dirname = preg_replace('/[^a-zA-Z0-9_-]/', '', $dirname);
        
        if (empty($dirname)) {
            echo "<p style='color:red'>Ошибка: введите корректное имя папки.</p>";
        } elseif (is_dir($dirname)) {
            echo "<p style='color:orange'>Папка с именем <b>$dirname</b> уже существует.</p>";
        } else {
            if (mkdir($dirname, 0777, true)) {
                echo "<p style='color:green'>✅ Директория <b>$dirname</b> успешно создана!</p>";
            } else {
                echo "<p style='color:red'>❌ Не удалось создать директорию.</p>";
            }
        }
    }
    ?>

    <br>
    <a href="index.php">← На главную</a>
</body>
</html>