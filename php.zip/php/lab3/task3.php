<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 3 - Частотный анализ строк</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        table { border-collapse: collapse; margin: 20px 0; width: 80%; }
        th, td { border: 1px solid #333; padding: 10px; text-align: left; }
        th { background-color: #f0f0f0; }
        .success { color: green; }
    </style>
</head>
<body>
    <h1>Задание 3 — Частотный анализ строк в файле</h1>

    <?php
    $filename = "text.txt";

    if (file_exists($filename)) {
        $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        $frequency = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '') {
                if (isset($frequency[$line])) {
                    $frequency[$line]++;
                } else {
                    $frequency[$line] = 1;
                }
            }
        }

        echo "<p class='success'>✅ Файл <b>$filename</b> успешно прочитан. Всего строк: " . count($lines) . "</p>";

        if (!empty($frequency)) {
            echo "<table>";
            echo "<tr><th>Строка</th><th>Количество повторений</th></tr>";
            
            // Сортируем по убыванию частоты
            arsort($frequency);
            
            foreach ($frequency as $str => $count) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($str) . "</td>";
                echo "<td><b>$count</b></td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    } else {
        echo "<p style='color:red'>❌ Файл <b>$filename</b> не найден!</p>";
        echo "<p>Создайте файл <b>text.txt</b> в папке lab3</p>";
    }
    ?>

    <br>
    <a href="index.php">← На главную</a>
</body>
</html>