<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Гостевая книга</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .message { 
            border: 1px solid #ddd; 
            padding: 15px; 
            margin: 15px 0; 
            border-radius: 8px; 
            background: #f9f9f9; 
        }
        .meta { color: #666; font-size: 0.9em; margin-bottom: 8px; }
        input, textarea { width: 100%; padding: 10px; margin: 8px 0; box-sizing: border-box; }
        textarea { height: 120px; }
    </style>
</head>
<body>
    <h1>Гостевая книга</h1>

    <!-- Форма добавления записи -->
    <h2>Оставить сообщение</h2>
    <form method="POST">
        <p>Имя: <input type="text" name="name" required placeholder="Ваше имя"></p>
        <p>Сообщение:<br>
            <textarea name="message" required placeholder="Напишите ваше сообщение..."></textarea>
        </p>
        <button type="submit">Отправить сообщение</button>
    </form>

    <hr>

    <h2>Предыдущие записи</h2>

    <?php
    $file = "guestbook.txt";

    // Добавление новой записи
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim($_POST['name'] ?? '');
        $message = trim($_POST['message'] ?? '');
        
        if (!empty($name) && !empty($message)) {
            $date = date("d.m.Y H:i:s");
            // Заменяем переносы строк на <br> для хранения
            $message = str_replace(["\r\n", "\r", "\n"], "<br>", $message);
            $entry = "$date | $name | $message" . PHP_EOL;
            
            if (file_put_contents($file, $entry, FILE_APPEND | LOCK_EX)) {
                echo "<p style='color:green'>✅ Сообщение успешно добавлено!</p>";
            } else {
                echo "<p style='color:red'>❌ Ошибка при сохранении.</p>";
            }
        } else {
            echo "<p style='color:red'>❌ Заполните все поля!</p>";
        }
    }

    // Вывод записей
    if (file_exists($file) && filesize($file) > 0) {
        $entries = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        echo "<p>Всего записей: " . count($entries) . "</p>";
        
        foreach ($entries as $entry) {
            // Безопасное разделение строки
            $parts = explode(" | ", $entry, 3);
            
            if (count($parts) === 3) {
                $date = $parts[0];
                $name = $parts[1];
                $message = $parts[2];
                
                echo "<div class='message'>";
                echo "<div class='meta'>$date — <b>" . htmlspecialchars($name) . "</b></div>";
                echo "<p>" . $message . "</p>";   // уже содержит <br>
                echo "</div>";
            }
        }
    } else {
        echo "<p>Гостевая книга пока пуста. Будьте первым!</p>";
    }
    ?>

    <br>
    <a href="index.php">← На главную</a>
</body>
</html>