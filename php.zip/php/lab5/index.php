<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Телефонный справочник</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h1 { color: #333; }
        ul { font-size: 18px; line-height: 2.2; }
    </style>
</head>
<body>
    <h1>Телефонный справочник</h1>
    <h2>Лабораторная работа №5</h2>
    
    <ul>
        <li><a href="search.php">Поиск контактов (для пользователей)</a></li>
        <li><a href="admin.php">Панель администратора</a></li>
    </ul>
</body>
</html>