<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "phonebook");
$result = $conn->query("SELECT * FROM contacts ORDER BY last_name");
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Панель администратора</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: left; }
        th { background-color: #f0f0f0; }
        .action-btn { padding: 5px 10px; }
    </style>
</head>
<body>
    <h1>Панель администратора</h1>
    <p>Вы вошли как: <b>Администратор</b></p>
    <a href="admin_logout.php">Выйти</a> | 
    <a href="index.php">На главную</a>

    <hr>
    <h2>Добавить новый контакт</h2>
    <form method="POST" action="admin_add.php">
        <p>Фамилия: <input type="text" name="last_name" required></p>
        <p>Имя: <input type="text" name="first_name" required></p>
        <p>Отчество: <input type="text" name="middle_name"></p>
        <p>Телефон: <input type="text" name="phone" required></p>
        <p>Адрес: <textarea name="address" rows="3"></textarea></p>
        <button type="submit">Добавить контакт</button>
    </form>

    <hr>
    <h2>Существующие контакты</h2>
    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Телефон</th><th>Адрес</th><th>Действия</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['last_name']) ?></td>
                <td><?= htmlspecialchars($row['first_name']) ?></td>
                <td><?= htmlspecialchars($row['middle_name']) ?></td>
                <td><?= htmlspecialchars($row['phone']) ?></td>
                <td><?= htmlspecialchars($row['address']) ?></td>
                <td>
                    <a href="admin_edit.php?id=<?= $row['id'] ?>" class="action-btn">✏ Изменить</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>Контактов пока нет.</p>
    <?php endif; ?>

    <?php $conn->close(); ?>
</body>
</html>