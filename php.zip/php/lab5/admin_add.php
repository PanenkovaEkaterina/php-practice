<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $last_name   = trim($_POST['last_name']);
    $first_name  = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name'] ?? '');
    $phone       = trim($_POST['phone']);
    $address     = trim($_POST['address']);

    $conn = new mysqli("localhost", "root", "", "phonebook");

    if ($conn->connect_error) {
        die("Ошибка подключения: " . $conn->connect_error);
    }

    $sql = "INSERT INTO contacts (last_name, first_name, middle_name, phone, address) 
            VALUES (?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $last_name, $first_name, $middle_name, $phone, $address);

    if ($stmt->execute()) {
        $message = "Контакт успешно добавлен!";
    } else {
        $message = "Ошибка при добавлении: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Результат добавления</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; text-align: center; }
        .success { color: green; font-size: 18px; }
        .error { color: red; font-size: 18px; }
    </style>
</head>
<body>
    <h1><?= isset($message) && strpos($message, 'успешно') !== false ? '✅ Успех!' : '❌ Ошибка' ?></h1>
    <p class="<?= isset($message) && strpos($message, 'успешно') !== false ? 'success' : 'error' ?>">
        <?= htmlspecialchars($message) ?>
    </p>
    
    <br><br>
    <a href="admin.php">← Добавить ещё контакт</a><br><br>
    <a href="index.php">На главную</a>
</body>
</html>