<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "phonebook");

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $result = $conn->query("SELECT * FROM contacts WHERE id = $id");
    $contact = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];
    $last_name = trim($_POST['last_name']);
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);

    $sql = "UPDATE contacts SET last_name=?, first_name=?, middle_name=?, phone=?, address=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $last_name, $first_name, $middle_name, $phone, $address, $id);
    
    if ($stmt->execute()) {
        header("Location: admin.php");
        exit();
    } else {
        echo "Ошибка обновления!";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Редактирование контакта</title>
    <style> body { font-family: Arial, sans-serif; margin: 40px; } input, textarea { width: 400px; padding: 8px; margin: 5px 0; } </style>
</head>
<body>
    <h1>Редактирование контакта</h1>

    <form method="POST">
        <input type="hidden" name="id" value="<?= $contact['id'] ?>">
        <p>Фамилия: <input type="text" name="last_name" value="<?= htmlspecialchars($contact['last_name']) ?>" required></p>
        <p>Имя: <input type="text" name="first_name" value="<?= htmlspecialchars($contact['first_name']) ?>" required></p>
        <p>Отчество: <input type="text" name="middle_name" value="<?= htmlspecialchars($contact['middle_name']) ?>"></p>
        <p>Телефон: <input type="text" name="phone" value="<?= htmlspecialchars($contact['phone']) ?>" required></p>
        <p>Адрес: <textarea name="address" rows="4"><?= htmlspecialchars($contact['address']) ?></textarea></p>
        <button type="submit">Сохранить изменения</button>
    </form>

    <br>
    <a href="admin.php">← Вернуться в панель</a>
</body>
</html>