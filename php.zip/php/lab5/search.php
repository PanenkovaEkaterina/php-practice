<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Поиск в телефонном справочнике</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        input[type="text"] { padding: 10px; width: 350px; font-size: 16px; }
        button { padding: 10px 20px; font-size: 16px; }
        table { border-collapse: collapse; margin-top: 20px; width: 90%; }
        th, td { border: 1px solid #333; padding: 10px; text-align: left; }
        th { background-color: #f0f0f0; }
        .not-found { color: red; font-size: 18px; }
    </style>
</head>
<body>
    <h1>Телефонный справочник</h1>
    <h2>Поиск (Уровень 2)</h2>

    <form method="GET">
        <p>Поиск по фамилии:<br>
            <input type="text" name="last_name" placeholder="Введите фамилию">
        </p>
        <p>Или по телефону:<br>
            <input type="text" name="phone" placeholder="+7XXXXXXXXXX или 8XXXXXXXXXX">
        </p>
        <button type="submit">Найти</button>
    </form>

    <?php
    $conn = new mysqli("localhost", "root", "", "phonebook");
    if ($conn->connect_error) {
        die("Ошибка подключения: " . $conn->connect_error);
    }

    if (isset($_GET['last_name']) && !empty($_GET['last_name'])) {
        $last_name = trim($_GET['last_name']);
        $sql = "SELECT * FROM contacts WHERE last_name LIKE ?";
        $stmt = $conn->prepare($sql);
        $search = "%$last_name%";
        $stmt->bind_param("s", $search);
    } 
    elseif (isset($_GET['phone']) && !empty($_GET['phone'])) {
        $phone = trim($_GET['phone']);
        $sql = "SELECT * FROM contacts WHERE phone = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $phone);
    }

    if (isset($stmt)) {
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<h3>Результат поиска:</h3>";
            echo "<table>";
            echo "<tr>
                    <th>Фамилия</th>
                    <th>Имя</th>
                    <th>Отчество</th>
                    <th>Телефон</th>
                    <th>Адрес</th>
                  </tr>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['last_name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['first_name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['middle_name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['phone']) . "</td>";
                echo "<td>" . htmlspecialchars($row['address']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='not-found'>Контакт не найден.</p>";
        }

        $stmt->close();
    }

    $conn->close();
    ?>

    <br>
    <a href="index.php">← На главную</a>
</body>
</html>