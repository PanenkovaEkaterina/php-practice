<?php
session_start();

if (isset($_POST['login']) && isset($_POST['password'])) {
    $login = trim($_POST['login']);
    $password = trim($_POST['password']);

    $conn = new mysqli("localhost", "root", "", "phonebook");

    if ($conn->connect_error) {
        die("Ошибка подключения: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM admins WHERE login = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $login, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_login'] = $login;
        header("Location: admin.php");
        exit();
    } else {
        $error = "Неверный логин или пароль!";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход для администратора</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; text-align: center; }
        input { padding: 10px; margin: 10px 0; width: 280px; font-size: 16px; }
        button { padding: 12px 30px; font-size: 16px; }
        .error { color: red; }
    </style>
</head>
<body>
    <h1>Вход в панель администратора</h1>

    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

    <form method="POST">
        <p>Логин:<br><input type="text" name="login" required></p>
        <p>Пароль:<br><input type="password" name="password" required></p>
        <button type="submit">Войти</button>
    </form>

    <br>
    <a href="index.php">← На главную</a>
</body>
</html>