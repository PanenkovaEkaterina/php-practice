<?php
$login = 'pit';
$password = '123';

if (!isset($_SERVER['PHP_AUTH_USER']) || 
    !isset($_SERVER['PHP_AUTH_PW']) ||
    $_SERVER['PHP_AUTH_USER'] !== $login || 
    $_SERVER['PHP_AUTH_PW'] !== $password) {
    
    header('WWW-Authenticate: Basic realm="Секретная зона"');
    header('HTTP/1.0 401 Unauthorized');
    echo "<h1>Доступ запрещён!</h1>";
    echo "<p>Неверный логин или пароль.</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 2 - HTTP Basic Auth</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
    </style>
</head>
<body>
    <h1>✅ Доступ разрешён!</h1>
    <p>Вы успешно авторизовались через системное окно браузера.</p>
    <p><strong>Логин:</strong> <?= htmlspecialchars($_SERVER['PHP_AUTH_USER']) ?></p>
    
    <br>
    <a href="index.php">← На главную</a>
    <br><br>
    <a href="task2.php" style="color:red">Выйти (обновить страницу)</a>
</body>
</html>