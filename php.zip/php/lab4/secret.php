<?php
session_start();

if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    header("Location: task1.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Секретная информация</title>
</head>
<body>
    <h1>Секретная страница</h1>
    <p>Здесь находится секретная информация, доступная только авторизованным пользователям.</p>
    <p>Вы вошли как: <b><?= htmlspecialchars($_SESSION['login']) ?></b></p>
    
    <a href="logout.php">Выйти</a><br><br>
    <a href="index.php">На главную</a>
</body>
</html>