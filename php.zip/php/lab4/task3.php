<?php
session_start();

function findUserFiles($dir) {
    $files = [];
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
    foreach ($iterator as $file) {
        if ($file->isFile() && $file->getExtension() === 'txt') {
            $files[] = $file->getPathname();
        }
    }
    return $files;
}

// Получаем все txt-файлы в папке lab4 и вложенных папках
$allFiles = findUserFiles(__DIR__);
$selectedFile = $_POST['users_file'] ?? ($allFiles[0] ?? 'users.txt');
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 3 + Дополнительное - Авторизация</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        input, select { padding: 8px; margin: 5px 0; width: 280px; }
        .error { color: red; }
        .success { color: green; }
    </style>
</head>
<body>
    <h1>Задание 3 + Дополнительное — Авторизация из любого файла</h1>

    <!-- Выбор файла -->
    <form method="POST" style="margin-bottom: 20px;">
        <p>Выберите файл с пользователями:<br>
            <select name="users_file">
                <?php foreach ($allFiles as $f): ?>
                    <option value="<?= htmlspecialchars($f) ?>" <?= $f === $selectedFile ? 'selected' : '' ?>>
                        <?= htmlspecialchars(basename($f)) ?> (<?= htmlspecialchars(str_replace(__DIR__.'/', '', $f)) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <button type="submit">Загрузить файл</button>
    </form>

    <!-- Форма входа -->
    <form method="POST">
        <input type="hidden" name="users_file" value="<?= htmlspecialchars($selectedFile) ?>">
        <p>Логин:<br><input type="text" name="login" required></p>
        <p>Пароль:<br><input type="password" name="password" required></p>
        <p>Ключевое слово (для смены пароля):<br>
           <input type="text" name="keyword" placeholder="необязательно"></p>
        <button type="submit">Войти</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
        $login = trim($_POST['login']);
        $password = trim($_POST['password']);
        $keyword = trim($_POST['keyword'] ?? '');

        if (file_exists($selectedFile)) {
            $lines = file($selectedFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $found = false;

            foreach ($lines as $line) {
                $parts = explode(':', $line);
                if (count($parts) >= 3) {
                    $u_login = trim($parts[0]);
                    $u_pass  = trim($parts[1]);
                    $u_keyword = trim($parts[2]);

                    if ($u_login === $login) {
                        $found = true;
                        if ($u_pass === $password) {
                            $_SESSION['auth'] = true;
                            $_SESSION['login'] = $login;
                            echo "<p class='success'>✅ Авторизация успешна! Добро пожаловать, <b>$login</b></p>";
                            break;
                        } elseif (!empty($keyword) && $u_keyword === $keyword) {
                            $_SESSION['change_login'] = $login;
                            $_SESSION['users_file'] = $selectedFile;
                            header("Location: change_password.php");
                            exit();
                        } else {
                            echo "<p class='error'>❌ Неверный пароль! Введите ключевое слово для смены.</p>";
                        }
                    }
                }
            }
            if (!$found) echo "<p class='error'>❌ Пользователь не найден.</p>";
        }
    }

    if (isset($_SESSION['auth']) && $_SESSION['auth'] === true) {
        echo "<p><a href='?logout=1'>Выйти</a></p>";
    }
    ?>

    <br>
    <a href="index.php">← На главную</a>
</body>
</html>