<?php
session_start();
session_destroy();
header("Location: task1.php");
exit();
?>