<?php
session_start(); // Обязательно в начале каждой страницы
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Задание 1 - Авторизация</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        input { padding: 8px; margin: 5px 0; width: 250px; }
    </style>
</head>
<body>
    <h1>Задание 1 — Авторизация с использованием сессий</h1>

    <?php
    if (isset($_POST['login']) && isset($_POST['passwd'])) {
        $_SESSION['login'] = trim($_POST['login']);
        $_SESSION['passwd'] = trim($_POST['passwd']);

        if ($_SESSION['login'] === 'pit' && $_SESSION['passwd'] === '123') {
            $_SESSION['auth'] = true;
            header("Location: secret.php");
            exit();
        } else {
            echo "<p style='color:red'>Неверный логин или пароль!</p>";
        }
    }
    ?>

    <form method="POST">
        <p>Login: <input type="text" name="login" required></p>
        <p>Password: <input type="password" name="passwd" required></p>
        <button type="submit">Войти</button>
    </form>

    <br>
    <a href="index.php">← На главную</a>
</body>
</html>