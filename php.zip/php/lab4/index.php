<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Лабораторная работа №4 - Сессии</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h1 { color: #333; }
        ul { font-size: 18px; line-height: 2.2; }
    </style>
</head>
<body>
    <h1>Лабораторная работа №4</h1>
    <h2>Работа с сессиями в PHP</h2>
    
    <ul>
        <li><a href="task1.php">1. Пример авторизации с сессиями</a></li>
        <li><a href="task2.php">2. Авторизация с системным окном (HTTP Basic)</a></li>
        <li><a href="task3.php">3. Авторизация с чтением из файла + смена пароля</a></li>
    </ul>
</body>
</html>