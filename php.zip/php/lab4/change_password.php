<?php
session_start();

if (!isset($_SESSION['change_login'])) {
    header("Location: task3.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_password'])) {
    $new_pass = trim($_POST['new_password']);
    $login = $_SESSION['change_login'];
    
    if (!empty($new_pass)) {
        $users_file = "users.txt";
        $lines = file($users_file, FILE_IGNORE_NEW_LINES);
        $new_lines = [];
        
        foreach ($lines as $line) {
            $parts = explode(':', $line);
            if ($parts[0] === $login) {
                $parts[1] = $new_pass; // меняем пароль
            }
            $new_lines[] = implode(':', $parts);
        }
        
        file_put_contents($users_file, implode("\n", $new_lines) . "\n");
        
        unset($_SESSION['change_login']);
        echo "<h2>Пароль успешно изменён!</h2>";
        echo "<a href='task3.php'>Вернуться к авторизации</a>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Смена пароля</title>
</head>
<body>
    <h1>Смена пароля для пользователя <?= htmlspecialchars($_SESSION['change_login']) ?></h1>
    <form method="POST">
        <p>Новый пароль:<br>
            <input type="password" name="new_password" required>
        </p>
        <button type="submit">Сменить пароль</button>
    </form>
</body>
</html>